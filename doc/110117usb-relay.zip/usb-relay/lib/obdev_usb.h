/* Based on: powerSwitch.c
 * 	Project: PowerSwitch based on AVR USB driver
 * 	Author: Christian Starkjohann
 * 	Creation Date: 2005-01-16
 * 	Tabsize: 4
 * 	Copyright: (c) 2005 by OBJECTIVE DEVELOPMENT Software GmbH
 *
 * License: GNU GPL v2
 */

int usbOpenDevice(usb_dev_handle **device, int vendor, char *vendorName, int product, char *productName);
